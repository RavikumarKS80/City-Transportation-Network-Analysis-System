import java.util.*;

public class Main {

    static class Graph {
        private Map<String, Map<String, Integer>> adjList = new HashMap<>();

        // Add city to graph
        public void addCity(String city) {
            adjList.putIfAbsent(city, new HashMap<>());
        }

        // Add a route between two cities with distance (or time) as weight
        public void addRoute(String city1, String city2, int weight) {
            adjList.putIfAbsent(city1, new HashMap<>());
            adjList.putIfAbsent(city2, new HashMap<>());
            adjList.get(city1).put(city2, weight);
            adjList.get(city2).put(city1, weight);
        }

        // Dijkstra’s Algorithm to find the shortest path between two cities (without PriorityQueue)
        public int findShortestPath(String start, String end) {
            Map<String, Integer> distances = new HashMap<>();
            Set<String> visited = new HashSet<>();
            Map<String, String> previousCities = new HashMap<>();

            // Initialize distances for all cities
            for (String city : adjList.keySet()) {
                distances.put(city, Integer.MAX_VALUE);
            }

            distances.put(start, 0);

            // Main Dijkstra loop
            while (visited.size() < adjList.size()) {
                // Find the city with the smallest distance that hasn't been visited yet
                String currentCity = getCityWithMinDistance(distances, visited);

                // If no city can be reached, exit the loop
                if (currentCity == null) {
                    break;
                }

                visited.add(currentCity);

                // If the current city is the destination, return the distance
                if (currentCity.equals(end)) {
                    return distances.get(currentCity);
                }

                // Explore neighbors of the current city
                for (Map.Entry<String, Integer> neighbor : adjList.get(currentCity).entrySet()) {
                    String neighborCity = neighbor.getKey();
                    int edgeWeight = neighbor.getValue();
                    int newDist = distances.get(currentCity) + edgeWeight;

                    if (newDist < distances.get(neighborCity)) {
                        distances.put(neighborCity, newDist);
                        previousCities.put(neighborCity, currentCity);
                    }
                }
            }

            return -1; // No path found
        }

        // Helper method to get the city with the minimum distance that hasn't been visited yet
        private String getCityWithMinDistance(Map<String, Integer> distances, Set<String> visited) {
            String minCity = null;
            int minDistance = Integer.MAX_VALUE;

            for (Map.Entry<String, Integer> entry : distances.entrySet()) {
                String city = entry.getKey();
                int distance = entry.getValue();

                if (!visited.contains(city) && distance < minDistance) {
                    minDistance = distance;
                    minCity = city;
                }
            }

            return minCity;
        }

        // Find cities that are directly connected to the given city
        public List<String> findDirectConnections(String city) {
            return new ArrayList<>(adjList.getOrDefault(city, new HashMap<>()).keySet());
        }

        // Print all cities and their connections
        public void printNetwork() {
            for (String city : adjList.keySet()) {
                System.out.println(city + ": " + adjList.get(city));
            }
        }
    }

    public static void main(String[] args) {
        Graph graph = new Graph();

        // Add cities (Indian cities)
        graph.addCity("Mumbai");
        graph.addCity("Chennai");
        graph.addCity("Delhi");
        graph.addCity("Bangalore");
        graph.addCity("Hyderabad");

        // Add transportation routes (roads, flights, etc.) between these cities
        graph.addRoute("Mumbai", "Chennai", 1300);  // Distance in kilometers
        graph.addRoute("Mumbai", "Delhi", 1500);
        graph.addRoute("Chennai", "Delhi", 2200);
        graph.addRoute("Delhi", "Bangalore", 2200);
        graph.addRoute("Bangalore", "Hyderabad", 700);
        graph.addRoute("Chennai", "Hyderabad", 650);

        // Print the network
        System.out.println("City Transportation Network:");
        graph.printNetwork();

        // Find the shortest path between Mumbai and Chennai
        System.out.println("\nShortest path from Mumbai to Chennai:");
        int shortestDistance = graph.findShortestPath("Mumbai", "Chennai");
        if (shortestDistance != -1) {
            System.out.println("Shortest distance: " + shortestDistance + " kilometers");
        } else {
            System.out.println("No path found.");
        }

        // Find direct connections for Delhi
        System.out.println("\nCities directly connected to Delhi:");
        List<String> directConnections = graph.findDirectConnections("Delhi");
        System.out.println(directConnections);
    }
